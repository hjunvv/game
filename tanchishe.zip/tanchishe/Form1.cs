﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tanchishe
{
    public partial class Form1 : Form

    {
        #region 成员变量
        Graphics g;  //画板
        int interval;  //格子宽度
        int margin;   //边距
        int x;//蛇x坐标
        int y;//蛇y坐标
        int gridNum;//格子数量
        int snakeLong;//蛇长
        Queue<Point> queuePoint;
        int foodX;//食物x坐标
        int foodY;//食物y坐标
        int scores;//得分
        int spend;//速度
        Direction current;//当前蛇移动的方向
        Direction pressing;//当前按键表示的方向

        #endregion 成员变量
        
        public Form1()
        {
            InitializeComponent();
        }
        public enum Direction { 
            Left =37,
            Up,
            Regit,
            Down,
        
        }
       /* protected override void OnPaint(PaintEventArgs e)
        {
            // base.OnPaint(e);
            Pen p = new Pen(Color.Blue, 1);
            margin = 10;
            interval = 20;
            gridNum = 18;
            for (int i=0;i<gridNum;i++) {
                g.DrawLine(p,margin,margin + i * interval, margin + gridNum*interval,margin + i*interval);
               g.DrawLine(p, margin+i*interval,margin , margin + i * interval, margin + gridNum * interval);
            }
            
        }*/
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            g = this.CreateGraphics();
            this.queuePoint = new Queue<Point>();
            margin = 10;
            gridNum = 18;
            interval = 20;
            g = this.CreateGraphics();
            //初始化方向设置为向左
            current = Direction.Regit;
            //初始得分为0
            this.scores = 0;
            //初始速度为0
            this.spend = 0;
        }


        private void Form1_Paint(object sender, PaintEventArgs e)
        {   
            /*Pen p = new Pen(Color.Blue,1);
            for (int i = 0; i <= gridNum; i++)
            {
                g.DrawLine(p, margin, margin+i*interval, margin + gridNum * interval, margin+i*interval);
                g.DrawLine(p, margin+i*interval, margin, margin+i*interval, margin + gridNum * interval);

            }*/
           /* x = 10;
            y = 5;
            SolidBrush b1 = new SolidBrush(Color.Red);
            g.FillRectangle(b1,margin+x*interval+1,margin+y*interval+1,interval-2,interval-2);
            snakeLong = (int)this.numericUpDown1.Value;
            SolidBrush b2 = new SolidBrush(Color.Black);
            for (int i=1;i<snakeLong;i++) {
                //左边
                g.FillRectangle(b2,margin+(x-i)*interval+1,margin+y*interval,interval-2,interval-2);
                //右边
                // g.FillRectangle(b2, margin + (x + i) * interval + 1, margin + y * interval, interval - 2, interval - 2);
                //上面
                // g.FillRectangle(b2, margin + x * interval + 1, margin + (y - i) * interval, interval - 2, interval - 2);
                //下面
                // g.FillRectangle(b2, margin + x * interval + 1, margin + (y + i) * interval, interval - 2,interval -2);
            }
            foodX = 10;
            foodY = 12;
            SolidBrush b3 =new SolidBrush(Color.Green);
            g.FillRectangle(b3,margin + foodX * interval +1,margin+foodY *interval+1,interval-1,interval-1);*/


        }
        protected override bool ProcessDialogKey(Keys keyData)
        {
            // return base.ProcessDialogKey(keyData);
            if (keyData == Keys.Enter)
            {
                label3.Text = "按space键暂停";
                timer1.Start();//开始，继续

            }
            else if (keyData == Keys.Space)
            {
                //按空格键时，显示Space
                label3.Text = "按enter键继续";
                timer1.Stop();//暂停
            }
            else
                /* label3.Text = keyData.ToString();*/
                pressing =(Direction) keyData;//转换方向键
            return false;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.label1.Text = "蛇长：" + numericUpDown1.Value;
            this.label2.Text = "速度：" + numericUpDown2.Value;
            this.label13.Text = "";
            this.numericUpDown1.Enabled = false;
            this.numericUpDown2.Enabled = false;
            this.numericUpDown3.Enabled = false;
            this.textBox1.Enabled = false;
            this.button1.Enabled = false;
            spend = (int)numericUpDown2.Value;
            timer1.Interval = 1000 - (spend - 1) * 100;//spend越大，Interval越小
            // 游戏结束后，再按游戏开始，需要重新画格子、蛇和食物
            // 画格子
            this.DrawGrid();
            // 画蛇
            this.GenerateSnake();
            // 画食物
            this.GenerateFood();
            //重新开始
            timer1.Start();

        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);//引发Paint事件处理（处理该事件时候调用Form1_Paint方法）
            //画格子
            this.DrawGrid();
            //画蛇
            this.GenerateSnake();
            //画食物
            this.GenerateFood();
            //g.Dispose();

        }
        private void DrawGrid()
        {
            //画格子
            //g.FillRectangle(new SolidBrush(this.BackColor), 0, 0, margin + gridNum * 20, margin + gridNum * 20);
            g.Clear(this.BackColor);
            Pen p = new Pen(Color.Blue, 1);
            for (int i = 0; i <= gridNum; i++)
            {
                g.DrawLine(p, margin + i * interval, margin, margin + i * interval, margin + gridNum * 20);
                g.DrawLine(p, margin, margin + i * interval, margin + gridNum * 20, margin + i * interval);
            }

        }

        private void GenerateSnake() {
            x = gridNum / 2 + 2;
            y = gridNum / 2 + 2;
            this.queuePoint.Clear();
            //新的蛇头
            SolidBrush b2 = new SolidBrush(Color.Red);
            //新的蛇身
            SolidBrush b3 = new SolidBrush(Color.Gray);
            //蛇的长度
            snakeLong = (int)numericUpDown1.Value;
            //蛇头
            g.FillRectangle(b2, (margin + 1) + x * interval, (margin + 1) + y * interval, interval - 2, interval - 2);//head
            this.queuePoint.Enqueue(new Point(x, y));

            for (int i = 1; i <= snakeLong; i++)
            {
                //蛇身
                g.FillRectangle(b3, (margin + 1) + x * interval - i * 20, (margin + 1) + y * interval, interval - 2, interval - 2);
                this.queuePoint.Enqueue(new Point(x - i, y));
            }

        }

        private void GenerateFood() {
            foodX = 10;// 目前设食物位置为固定值
            foodY = 4;
            g.FillRectangle(new SolidBrush(Color.Green), 11 + foodX * interval, 11 + foodY * interval, 18, 18);

        }
        //蛇的移动
        public void SnakeMove() {
            int i;
            //蛇头
            SolidBrush b2 = new SolidBrush(Color.Red);
            //食物
            SolidBrush b1 = new SolidBrush(Color.Green);
            //蛇身
            SolidBrush b3 = new SolidBrush(Color.Gray);
            //障碍物
            SolidBrush b4 = new SolidBrush(BackColor);
            if (current == Direction.Up)
            { y--; }
            if (current == Direction.Down)
            { y++; }
            if (current == Direction.Left)
            { x--; }
            if (current == Direction.Regit)
            { x++; }
            //吃 food（食物）
            if (x == foodX && y == foodY)
            {
                snakeLong++;
                int j = (int)queuePoint.LongCount() - 1;//蛇尾的坐标入队
                queuePoint.Enqueue(new Point(queuePoint.ElementAt(j).X, queuePoint.ElementAt(j).Y));
                AddScore();
            }
            //如果坐标和墙壁坐标相同，游戏暂停，调用GameOver方法（函数）
            if (x >= 18 || x <= -1 || y <= -1 || y >= 18)
            {
                timer1.Stop();
                GameOver();
                return;
            }
            //蛇头移动
            g.FillRectangle(b2, margin + 1 + x * interval, margin + 1 + y * interval, 18, 18);
            queuePoint.Enqueue(new Point(x, y));
            //蛇身移动
            int x1, y1;
            for (i = 1; i <= snakeLong; i++)
            {
                x1 = queuePoint.First().X;
                y1 = queuePoint.First().Y;
                queuePoint.Dequeue();
                g.FillRectangle(b3, 11 + x1 * interval, 11 + y1 * interval, 18, 18);
                queuePoint.Enqueue(new Point(x1, y1));
            }
            //最后一格用背景色填掉
            x1 = queuePoint.First().X;
            y1 = queuePoint.First().Y;
            queuePoint.Dequeue();
            g.FillRectangle(b4, 11 + x1 * interval, 11 + y1 * interval, 18, 18);
            //CreateFood();

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //垂直两键的值的绝对值为1/3
            int a = Math.Abs((int)current - (int)pressing);
            //如果绝对值为1/3
            if (a==1||a==3) {
                //改变方向
                current = (Direction)pressing;
            }
            this.SnakeMove();
        }
        //游戏结束
        public void GameOver() {
            label13.Text = "Game Over";
           //如果舌头和墙壁碰撞就显示Game Over
            if (x >= 18 || x <= -1 || y <= -1 || y >= 18) {
                label13.Visible = true;

            } 

            this.numericUpDown1.Enabled = true;
            this.numericUpDown2.Enabled = true;
            this.button1.Enabled = true;
        
        }
        //吃到食物之后就增加分数
        public void AddScore() {
            scores++;
            //每吃到一个食物，加50分
            label6.Text = (scores * 50).ToString();
        }
    }
}
